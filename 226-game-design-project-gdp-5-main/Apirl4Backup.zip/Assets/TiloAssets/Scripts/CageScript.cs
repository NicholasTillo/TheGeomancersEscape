using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CageScript : MonoBehaviour
{
    public GameObject myPrefab;
    public bool triggered = false;
    protected float Initiative = 0f; 
    protected Transform player;
    // Start is called before the first frame update
    void Start(){
        player = GameObject.Find("Player").transform;
    }


    // Update is called once per frame
    void Update()
    {
        if(triggered){

            if (this.Initiative > 0){
                this.Initiative -= Time.deltaTime;
            }
            else{
                summonHomie();
                this.Initiative = 10;
        }
        }   
        
        
        

    }
    void summonHomie(){
        Instantiate(myPrefab, this.transform.position, this.transform.rotation);
    }
}
