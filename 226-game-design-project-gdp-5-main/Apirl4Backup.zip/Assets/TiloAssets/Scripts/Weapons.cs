using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon
//Defining what it means to be a weapon. 
{
   //
    public string Wname;
    //How much damage the weapon deals, 
    public int damage;
    //How fast the 
    public float hitSpeed;
   //How fast the player can attack again afterwards. 
    public float reloadSpeed;

    public Weapon(string Pname, int Pdamage, float phitSpeed, float PreloadSpeed){
        Wname = Pname;
        damage = Pdamage;
        hitSpeed = phitSpeed;
        reloadSpeed = PreloadSpeed;

    }
   //easy constructors for the starting weapons. 
    public static Weapon Sword(){
       return new Weapon("Sword",2,0.5f,1.5f);
    }
    public static Weapon Gun(){
       return new Weapon("Gun",1,0.5f,1.5f);
    }
    public static Weapon Yoyo(){
       return new Weapon("Yo-yo",1,1f,2f);
    }

}
