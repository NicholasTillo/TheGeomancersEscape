using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldScript : MonoBehaviour
{
    // Start is called before the first frame update
    
    public int worldNum;
    public Transform summonSpot; 
    public GameObject Boss;
    public Quaternion summonRotation;

    public int requiredCoin;

  

    // Update is called once per frame

    public void summonBoss(){
        Instantiate(Boss, summonSpot.position, summonRotation);
    }


}
