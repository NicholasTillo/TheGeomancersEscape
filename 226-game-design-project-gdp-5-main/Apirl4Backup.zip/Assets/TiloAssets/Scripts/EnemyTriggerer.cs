using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTriggerer : MonoBehaviour
{
    // Start is called before the first frame update
    void OnTriggerEnter(Collider other){
        if(other.gameObject.tag == "Frog"){
            other.gameObject.GetComponent<EnemyStats>().triggered = true;
        }
        
        if(other.gameObject.tag == "cage"){
            other.gameObject.GetComponent<CageScript>().triggered = true;
        }
        Debug.Log(other.gameObject.name +" Triggered.");
    }
    void OnTriggerExit(Collider other){
        if(other.gameObject.tag == "Frog"){
            other.gameObject.GetComponent<EnemyStats>().triggered = false;
        }
        if(other.gameObject.tag == "cage"){
            other.gameObject.GetComponent<CageScript>().triggered = false;
        }
    }
}
