using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonScript : MonoBehaviour
{
    bool Triggered = false;
    public Transform triggeredObject;
    void Start(){
    }
    void OnTriggerEnter(Collider other){
        if(other.tag == "Frog" && !Triggered){
            triggeredObject.GetComponent<SpriteRenderer>().enabled = true; 
            triggeredObject.transform.GetChild(0).GetComponent<BoxCollider>().enabled = false; 
        }   

    }
}
