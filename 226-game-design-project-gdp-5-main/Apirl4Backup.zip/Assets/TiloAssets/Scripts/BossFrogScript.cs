using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossFrogScript : EnemyStats
{
    // Start is called before the first frame update
    string Action = "DoubleJump";
    bool changeRotation = true;
    
    void Start(){
        rb = gameObject.GetComponent<Rigidbody>();
        player = GameObject.Find("Player").transform;
        Quaternion startDirection = transform.rotation;


    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if(isGrounded){
            rb.velocity = new Vector3(0,0,0);
            if(changeRotation){
                Quaternion x = Quaternion.LookRotation(transform.forward, player.position - this.transform.position + new Vector3(0f,0f,90f));
                x = Quaternion.AngleAxis(90, transform.forward) * x;
                Debug.Log(x);
                this.transform.rotation = x;
            }   
            
        }

        if(triggered){
            if (this.Initiative > 0){
                this.Initiative -= Time.deltaTime;
            }
            else{
                if(Action == "DoubleJump"){
                    Jump2();
                    this.Initiative = 0.5f;
                    Action = "Jump";
                }
                else if(Action == "Jump"){
                    Jump2();
                    this.Initiative = Random.Range(2.0f, 3.0f);
                    Action = RandomAction();
                }
                else if(Action == "Attack"){
                    changeRotation = false;
                    this.transform.GetChild(2).GetComponent<Toungue>().Attack();
                    this.Initiative = 1f;
                    Action = "Stop";
                }
                else if(Action == "Stop"){
                    changeRotation = true;
                    this.transform.GetChild(2).GetComponent<Toungue>().StopSS();
                    this.Initiative = Random.Range(2.0f, 3.0f);
                    Action = RandomAction();


                }
            }
        }
        

        //Do Gravity if the enemy is not on the ground.  
        if(!isGrounded){
            Gravity();  
            slowDown();
            Quaternion x = Quaternion.LookRotation(down, player.position - this.transform.position);
            this.transform.rotation = x;
        }
    }
    string RandomAction(){
        string[] options = {"Jump","DoubleJump","Attack"};
        //string x = options[(int)Random.Range(0.0f, 2.99f)];
        string x = "Attack";
        Debug.Log(x);
        return x;
    }


}
