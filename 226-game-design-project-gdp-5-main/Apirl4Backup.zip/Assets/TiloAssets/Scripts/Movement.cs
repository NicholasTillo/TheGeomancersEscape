using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    //Movement Varaibles, 
    float moveSpeed = 1;
    Vector3 direction;
    //Animation Variables 
    public Vector3 prevMovement;
    Quaternion lookingDirection;
    public Vector3 down; 


    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        
        float xMove = Input.GetAxisRaw("Horizontal"); // d key changes value to 1, a key changes value to -1
        float yMove = Input.GetAxisRaw("Vertical"); // w key changes value to 1, s key changes value to -1
    
        if (transform.position.x >= 5.0 && 0 <= transform.position.z && transform.position.z <= 10 && 
        -5 <= transform.position.y && transform.position.y <= 5)  // movement on right
        {
             direction = new Vector3(0, yMove * moveSpeed, xMove * moveSpeed);
        }
        else if (transform.position.x <= -5.0 && 0 <= transform.position.z && transform.position.z <= 10 && 
        -5 <= transform.position.y && transform.position.y <= 5)  // movement on left
        {
             direction =new Vector3(0, yMove * moveSpeed, -xMove * moveSpeed);
        }
        else if (transform.position.y >= 5.0 && 0 <= transform.position.z && transform.position.z <= 10 && 
        -5 <= transform.position.x && transform.position.x <= 5)  // movement on top
        {
             direction =new Vector3(xMove * moveSpeed, 0, yMove * moveSpeed);
        }
        else if (transform.position.y <= -5.0 && 0 <= transform.position.z && transform.position.z <= 10 && 
        -5 <= transform.position.x && transform.position.x <= 5)  // movement on bottom
        {
            direction =new Vector3(xMove * moveSpeed, 0, -yMove * moveSpeed);
        }
        else if (transform.position.z >= 10 && -5 <= transform.position.x && transform.position.x <= 5 && 
        -5 <= transform.position.y && transform.position.y <= 5)  // movement on back
        {
             direction = new Vector3(-xMove * moveSpeed, yMove * moveSpeed, 0);
        }
        else if (transform.position.z <= 0 && -5 <= transform.position.y && transform.position.y <= 5 && 
        -5 <= transform.position.x && transform.position.x <= 5)  // movement on front
        {
             direction = new Vector3(xMove* moveSpeed, yMove * moveSpeed,0);
        }
        

        
        // Creates velocity in direction of value equal to keypress (WASD). rb.velocity.y deals with falling + jumping by setting velocity to y.
        //transform.rotation = Quaternion.LookRotation(direction);
        
        //check if the movement has changed from the last one, if it has, we must change the 
        //direction we are looking
        if(prevMovement != direction && direction != Vector3.zero){
            ChangeAnimationState(xMove, yMove,direction);
        }
        prevMovement = direction; 
        

    }
    public void SetClosestFloor(){
        float lowestDistance = 1000;
        GameObject lowest = null;

        foreach(GameObject floor in  GameObject.Find("FloorList").GetComponent<CalculateFloorList>().FloorList){
            float distance = Vector3.Distance(floor.transform.position, this.transform.position);
            if(distance < lowestDistance){
                lowest = floor;
                lowestDistance = distance;

            }
        }
        down = lowest.gameObject.GetComponent<Floor>().down;
    }
    //Change the direction the sprite is looking to be (x,y)
    void ChangeAnimationState(float x, float y, Vector3 look){
        Debug.Log(look);
        Debug.Log(down);
        this.gameObject.transform.rotation = Quaternion.LookRotation(-down, look);
    }

}



/* 
Very bad change animation state
        //Depends on where we are moving
        if(x == 1){
            lookingDirection = Quaternion.Euler(0,0,270 + 45*y);
        }
        if(x == 0){
            if(y == 1){
                lookingDirection = Quaternion.Euler(0,0,0);
            }
            if(y == 0){
                return;
            }
            if(y == -1){
                lookingDirection = Quaternion.Euler(0,0,180);
            }
        }
        if(x == -1){
            lookingDirection = Quaternion.Euler(0,0,90 - 45*y);
        }
        //change the direction we are looking to be that.
        transform.rotation = lookingDirection;
*/