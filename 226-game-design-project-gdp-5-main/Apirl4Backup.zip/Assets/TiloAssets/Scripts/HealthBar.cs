using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;  // will allow us to create a variable to store our slider.

public class HealthBar : MonoBehaviour
{
    public Slider slider;
    public Gradient gradient;
    public Image fill;

    // we make these functions public so that we can call them from other scripts.
    public void setMaxHealth(int health){
        slider.maxValue = health;
        slider.value = health;  // starts at max health.

        fill.color = gradient.Evaluate(1f);
    }

    public void setHealth(int health){
        slider.value = health;

        fill.color = gradient.Evaluate(slider.normalizedValue);
    }
}
