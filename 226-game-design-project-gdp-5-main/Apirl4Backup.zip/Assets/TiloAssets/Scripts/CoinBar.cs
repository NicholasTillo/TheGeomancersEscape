using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CoinBar : MonoBehaviour
{
    // Start is called before the first frame update
    public TextMeshProUGUI textDisplay;
    public void setCoin(int value){
        textDisplay.text = value.ToString();
        
    }
}
