using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStats : MonoBehaviour
{

    public int Health;
    protected Rigidbody rb;
    protected Quaternion lookingDirection;
    //If the enemy is in 2d
    protected bool isGrounded = true;
    //How much the enemy jumps 
    public int jumpforce = 5;
    public int gravForce = 3;
    protected float Initiative = 0f; 
    public bool triggered = false;

    public Vector3 down;
    protected Transform player;
    protected Quaternion startDirection;
     

    void Start(){
        rb = gameObject.GetComponent<Rigidbody>();
        player = GameObject.Find("Player").transform;
        Quaternion startDirection = transform.rotation;
        SetClosestFloor();

    }
    public void ChangeJumpForce(int i){
        this.jumpforce = i;
    }
    public void ChangeGravity(int i){
        this.gravForce = i;
    }
    void FixedUpdate()
    {
        if(isGrounded){
            rb.velocity = new Vector3(0,0,0);
  
        }
        if(triggered){
            if (this.Initiative > 0){
                this.Initiative -= Time.deltaTime;
            }
            else{
                Jump2();
                this.Initiative = Random.Range(3.0f, 5.0f);
        }
        }
        
        //Do Gravity if the enemy is not on the ground.  
        if(!isGrounded){
            Gravity();  
            slowDown();
            Quaternion x = Quaternion.LookRotation(down, player.position - this.transform.position);
            this.transform.rotation = x;
        }
    }
    protected void Gravity(){
        //Add a downward force onto them.
        
        rb.AddForce(down*gravForce);
    }    
    public void Damage(int damage){
        Health -= damage;
        if(Health <=0){
            Death();
        }
    }
    public void Death(){
        //Kill the enemy and destroy all its children
        foreach (Transform child in gameObject.transform) {
            Destroy(child.gameObject);
        }
        Destroy(gameObject);
    }
    
    
    
    protected void Jump2(){
        //find the distance between the player and the enemy. 
        var direction = (GameObject.Find("Player").transform.position - transform.position);
        Transfer3D();
        //Create the direction he wants to jump, -1 is a placeholder for "up" of the face. 
        Vector3 JDirect = new Vector3(direction.x/6, direction.y/6,direction.z/6);
        JDirect = JDirect - down*2;
        rb.AddForce(JDirect * jumpforce,ForceMode.Impulse);
        this.transform.localEulerAngles = down*90;


    }
    public void SetClosestFloor(){
        float lowestDistance = 1000;
        GameObject lowest = null;

        foreach(GameObject floor in  GameObject.Find("FloorList").GetComponent<CalculateFloorList>().FloorList){
            float distance = Vector3.Distance(floor.transform.position, this.transform.position);
            if(distance < lowestDistance){
             
                lowest = floor;
                lowestDistance = distance;
            }
        }
        down = lowest.gameObject.GetComponent<Floor>().down;
        this.transform.rotation = lowest.gameObject.GetComponent<Floor>().transform.rotation;
    }

    protected void Move(){
        //This code is not used at all lol, but it might be useful for another enemy.
        //Find the distance between the player and the enemy. 
        var direction = (GameObject.Find("Player").transform.position - transform.position).normalized;
        //If the enemy if within 10 units, they start to move 
        if(direction.magnitude <= 10){
            direction.z = 0;
            Vector3 S = direction.normalized;
            //Change Rotation in the direction they are moving.
                if(direction.normalized.x >= 0){
                    lookingDirection = Quaternion.Euler(0,0,270 + 45*direction.normalized.y);
                }

                if(direction.normalized.x <= 0){
                    lookingDirection = Quaternion.Euler(0,0,90 - 45*direction.normalized.y);
                }
                transform.rotation = lookingDirection;
        }
    }

    
    protected void OnCollisionEnter(Collision monkeyBalls){
        //If its colliding with the backdrop, transfer into 2d. 

        if(monkeyBalls.gameObject.name == "Backdrop"){
            Transfer2D(monkeyBalls);
        }
        if(monkeyBalls.gameObject.tag == "Obsticle"){
            Pause();
        }

    }
    protected void OnTriggerEnter(Collider monkeyBalls){
        Debug.Log(monkeyBalls.gameObject.name);
        if(monkeyBalls.gameObject.name == "Player"){
            Debug.Log("Player");
            monkeyBalls.gameObject.GetComponent<PlayerStats>().Damage(1);
        }
    }



    protected void Pause(){
        //Make it get affected by gravity.
        isGrounded = true;
        //Remove all lingering inertia. 
        rb.velocity = new Vector3(0,0,0);
        //Allow it to turn again
        rb.constraints = RigidbodyConstraints.None;
    }

    protected void Transfer2D(Collision Floor){
        //Make the square invisible and the cuibe visible. 
        this.transform.GetChild(0).GetComponent<Renderer>().enabled = true;
        this.transform.GetChild(1).GetComponent<MeshRenderer>().enabled = false;
        //Make it get affected by gravity.
        isGrounded = true;
        //Remove all lingering inertia. 
        rb.velocity = new Vector3(0,0,0);
        //Allow it to turn again
        this.rb.rotation = Floor.transform.rotation;
        rb.constraints = RigidbodyConstraints.None;

        
    }
    protected void Transfer3D(){
        //make the square visible and the cube invisible. 
        this.transform.GetChild(0).GetComponent<Renderer>().enabled = false;
        this.transform.GetChild(1).GetComponent<MeshRenderer>().enabled = true;
        //Stop it from getting affected by gravity. 
        isGrounded = false;
        //For the frog, lock the x and y velocity so he jumps in a straight line,
        rb.constraints = RigidbodyConstraints.FreezeRotation;

    }
    protected void slowDown(){
        //slow down by 5% every frame or so so the movement is less slidey. 
        rb.velocity = Vector3.Scale(rb.velocity, new Vector3(0.999f,0.999f,0.999f));
    }

}



/* 
Jumping Legacy Code. 

    void Jump(){
        this.transform.GetChild(1).GetComponent<MeshRenderer>().enabled = true;
        this.transform.GetChild(0).GetComponent<Renderer>().enabled = false;
        StartCoroutine(DoAnimatie());
    }

    IEnumerator DoAnimatie(){
    this.transform.GetChild(1).GetComponent<Animator>().Play("SpiderJump");
    yield return new WaitForSeconds(1f);
    this.transform.GetChild(1).GetComponent<Animator>().Play("NewState");
    this.transform.GetChild(0).GetComponent<Renderer>().enabled = true;
    this.transform.GetChild(1).GetComponent<MeshRenderer>().enabled = false;
    this.transform.position = this.transform.GetChild(1).transform.position;
    this.transform.position = new Vector3(this.transform.position.x,this.transform.position.y,0);
    }
*/