using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats : MonoBehaviour
{   
    //Initiative defines how long until the player can attack again.
    public float Initiative = 0;


    public int maxHealth;
    public int currentHealth;
    public HealthBar healthBar;

    public int coinCount; 
    public CoinBar coinBar; 

    public WorldScript worldInfo; 


    //Create the three starting weapons. and apply save them here, 
    Weapon Sword = Weapon.Sword();
    Weapon Gun = Weapon.Gun();
    Weapon Yoyo = Weapon.Yoyo();

    //Which weapon is currently held by the player. 
    [SerializeField] public Weapon CurrentWeapon;  
    
    // Start is called before the first frame update
    void Start()
    {
        maxHealth = 10; //The players starting hp is 10
        currentHealth = maxHealth; //The players starting hp is 10

        worldInfo =  GameObject.FindWithTag("world").GetComponent<WorldScript>();

        CurrentWeapon = Sword;//The player will have sword out when they start. 
        healthBar.setMaxHealth(maxHealth);
    }

    // Update is called once per frame
    void Update()
    {
        //THe keys,1,2,3 change the weapons to their corresponding weapon. 
         if(Input.GetKeyDown("1")){
            ChangeWeapon(Sword);
        }
        if(Input.GetKeyDown("2")){
            ChangeWeapon(Gun);

        }
        if(Input.GetKeyDown("3")){
            ChangeWeapon(Yoyo);

        }
    }

    public void ChangeWeapon(Weapon ChangingWeapon){
        //Change the weapon by turning off and on diffrent renderers
        GameObject.Find(CurrentWeapon.Wname).GetComponent<Renderer>().enabled = false;
        CurrentWeapon = ChangingWeapon;
        GameObject.Find(ChangingWeapon.Wname).GetComponent<Renderer>().enabled = true;

    }
    //Apply damage to the player.
    public void Damage(int damage){
        currentHealth -= damage;
        if(currentHealth <=0){
            PlayerStats.GameOver();
        }
        healthBar.setHealth(currentHealth);
    }

    public void collectCoin(){
        coinCount += 1;
        coinBar.setCoin(coinCount);
        if(coinCount == worldInfo.requiredCoin){
           worldInfo.summonBoss();
        }
    }
    public static void GameOver(){
            Debug.Log("Death");
    }



}

