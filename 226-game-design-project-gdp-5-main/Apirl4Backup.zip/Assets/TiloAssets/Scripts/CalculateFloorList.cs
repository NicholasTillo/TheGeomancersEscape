using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CalculateFloorList : MonoBehaviour
{
    public GameObject[] FloorList;
    // Start is called before the first frame update
    void Start()
    {
        FloorList = GameObject.FindGameObjectsWithTag("Floor");
    }
}
