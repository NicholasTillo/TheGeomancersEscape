using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour
{
    Vector3 point;
    float xRot; 
    float yRot;
    float zRot;
    // Start is called before the first frame update
    void Start()
    {
        point = GameObject.Find("Cube (1)").transform.position;
        point = new Vector3(0,0,5);
    }

    // Update is called once per frame
    void Update()
    {
        float xMove = Input.GetAxisRaw("Horizontal"); // d key changes value to 1, a key changes value to -1
        float yMove = Input.GetAxisRaw("Vertical"); // w key changes value to 1, s key changes value to -1
        if(Input.GetKey("up")){
            xRot = 1f;
         }
         else if(Input.GetKey("down")){
            xRot = -1f;
         }
         else {
            xRot = 0f;
         }
         if(Input.GetKey("left")){
            
            yRot = 1f;
         }
         else if(Input.GetKey("right")){
            
            yRot = -1f;
            
         }
         else{
            yRot = 0f;
         }
        if(Input.GetKey("q")){
        zRot = 1f;
         }
        else if(Input.GetKey("e")){
        zRot = -1f;
        }
        else{
            zRot = 0f;
        }

        transform.RotateAround(point,new Vector3(xRot,yRot,zRot),100* Time.deltaTime);




    }
}
