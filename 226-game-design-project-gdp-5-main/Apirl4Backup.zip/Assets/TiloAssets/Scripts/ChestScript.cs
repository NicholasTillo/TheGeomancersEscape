using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChestScript : MonoBehaviour
{
    // Start is called before the first frame update
    SpriteRenderer sprite;
    bool open = false;
    public bool isDoubleChest;

    public Transform prefab;


    int health;
    public GameObject coinPos1;
    public GameObject coinPos2;
    public GameObject coinPos3;
    public GameObject coinPos4;

    void Start(){
        sprite = gameObject.GetComponent<SpriteRenderer>();
        if(isDoubleChest){
            health = 4;
        }
    }
    protected void OnTriggerEnter(Collider other){    
        if(!open){
            if(other.gameObject.tag == "Weapon" && !isDoubleChest){
                Debug.Log("Open");
                sprite.enabled = true;
                open = true;
                if(coinPos1 != null){
                    Instantiate(prefab, coinPos1.transform.position, this.transform.rotation);
                }
            }
            else if(other.gameObject.tag == "Weapon" && health <= 0){
                Debug.Log("Open");
                sprite.enabled = true;
                open = true;
                if(coinPos1 != null){
                    Instantiate(prefab, coinPos1.transform.position, this.transform.rotation);
                }
                if(coinPos2 != null){
                     Instantiate(prefab, coinPos2.transform.position, this.transform.rotation);
                }
                if(coinPos3 != null){
                     Instantiate(prefab, coinPos3.transform.position, this.transform.rotation);
                }
                if(coinPos4 != null){
                    Instantiate(prefab, coinPos4.transform.position, this.transform.rotation);
                }
               


            }
            else {
                health -= 1;
            }
        }
        
    }


}
