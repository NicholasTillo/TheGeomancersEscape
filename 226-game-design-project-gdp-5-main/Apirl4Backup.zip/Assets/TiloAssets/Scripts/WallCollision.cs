using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallCollision : MonoBehaviour
{
    public Vector3 rotationAngle;
    public GameObject teleportPoint;
    public GameObject floor;

    void OnTriggerEnter(Collider other)
    {
        Debug.Log(other.gameObject.name);

        if(other.gameObject.name == "Player"){
            other.transform.position = teleportPoint.transform.position;
            other.transform.rotation = Quaternion.Euler(rotationAngle);

            other.transform.GetChild(0).GetComponent<Movement>().SetClosestFloor();
            other.transform.GetComponent<PlayerController>().movementInput = new Vector3(0,0,0);
        }
        else if (other.gameObject.name == "Enemy"){
            other.gameObject.GetComponent<EnemyStats>().SetClosestFloor();
        }

    }
}